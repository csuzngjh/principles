# 环境快照 (Environment Snapshot)

> 最后更新: 2026-03-12 10:30:00

## 系统信息 (System Information)

- **操作系统**: Linux 6.1.0-42-cloud-amd64
- **工作目录**: /home/csuzngjh/clawd
- **Git 仓库**: 是 - main 分支
- **Shell**: bash
- **Node.js 版本**: v20.x.x
- **平台**: OpenClaw Gateway (WebSocket)

## 可用工具 (Available Tools)

### OpenClaw 内置工具
- `read` - 读取文件内容
- `write` - 写入文件
- `edit` - 编辑文件
- `bash` - 执行 shell 命令
- `glob` - 文件模式匹配
- `grep` - 内容搜索

### Skills (技能)
- `/init-strategy` - 初始化项目战略
- `/manage-okr` - 管理 OKR 目标
- `/evolve-task` - 触发进化任务
- `/bootstrap-tools` - 工具引导
- `/thinking-os` - 思维操作系统
- `/pd-status` - 痛觉系统状态
- `/trust` - 信任系统查询

## 目录结构 (Directory Structure)

```
/home/csuzngjh/clawd/
├── docs/                   # 长期记忆
│   ├── PROFILE.json       # 用户档案
│   ├── PLAN.md            # 实现计划
│   ├── PRINCIPLES.md      # 进化原则
│   ├── THINKING_OS.md     # 思维模型
│   ├── IDENTITY.md        # 智能体身份
│   ├── SOUL.md            # 灵魂和价值观
│   ├── USER.md            # 用户画像
│   └── okr/               # 目标管理
│       └── CURRENT_FOCUS.md
├── memory/                # 短期记忆
│   ├── 2026-03-12.md      # 今日笔记
│   └── .state/            # 状态目录
│       ├── logs/          # 事件日志
│       ├── evolution_queue.json
│       └── .pain_flag
└── .state/                # 插件状态（v1.5.0+）
    ├── AGENT_SCORECARD.json
    └── pain_dictionary.json
```

## 环境变量 (Environment Variables)

```bash
HOME=/home/csuzngjh
PATH=/usr/local/bin:/usr/bin:/bin
LANG=zh_CN.UTF-8
```

## Git 状态 (Git Status)

```bash
Branch: main (clean)
Last commit: 14b103a test: 添加 PRINCIPLES.md 注入测试
Remote: origin
```

## 特殊配置 (Special Configuration)

- **Principles Disciple**: v1.5.0
- **Trust Engine**: V2 (cold start support)
- **State Directory**: /home/csuzngjh/clawd/.state (v1.5.0 迁移)
- **Evolution Worker**: 运行中 (90s 轮询)

---
_此文件在每次启动时更新 | This file is updated on every startup_
